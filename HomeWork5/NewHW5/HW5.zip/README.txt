HOW TO RUN
1. Create virtual environment
    python -m venv venv

# Activate virtual environment
    # On Windows:
        venv\Scripts\activate
    # On macOS/Linux:
        source venv/bin/activate

2. Install requirements
    pip install -r requirements.txt

3. Run the application
    python RRT.py

Note: you must use python 3.8 for dubins